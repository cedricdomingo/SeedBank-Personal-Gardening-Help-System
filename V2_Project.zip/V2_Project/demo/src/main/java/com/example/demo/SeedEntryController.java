package com.example.demo;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.scene.control.ComboBox;

import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.util.ResourceBundle;

public class SeedEntryController implements Initializable {

    // If you ComboBox is going to display Strings, you should define that datatype here
    @FXML
    private ComboBox<String> seedEntry_type_comboBox;
    @FXML
    private ComboBox<String> seedEntry_methodObtained_comboBox;

    @FXML
    private Label sidebar_loggedInAs;

    @FXML
    private Button sidebar_logout_btn;

    @FXML
    private Label sidebar_preferredAlias;

    @FXML
    private void initialize() {
        seedEntry_type_comboBox.setItems(FXCollections.observableArrayList(getData()));
        seedEntry_methodObtained_comboBox = new ComboBox();
        seedEntry_methodObtained_comboBox.getItems().add("Harvested");
        seedEntry_methodObtained_comboBox.getItems().add("Purchased");
        seedEntry_methodObtained_comboBox.getItems().add("Wasted");
    }

    @FXML
    private Label welcomeText;
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField seedEntry_quantity_textField,
            seedEntry_day_textField,
            seedEntry_month_textfield,
            seedEntry_year_textfield;


    //SIDE NAVIGATION BAR /////////////////////////////////////////////////////////////////////////////
    public void goToDashboard(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToSeedEntry(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("seedEntry.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToSearch(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("search.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToPlantingSchedule(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("plantingSchedule.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToUserSettings(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("userSettings.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToReports(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("reports.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void logoutButton(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("login.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    //SIDE NAVIGATION BAR /////////////////////////////////////////////////////////////////////////////


    /**
     * Here we will define the method that builds the List used by the ComboBox
     */
    private List<String> getData() {
        Connection connection;
        PreparedStatement statement;
        ResultSet set = null;

        // Define the data you will be returning, in this case, a List of Strings for the ComboBox
        List<String> options = new ArrayList<>();

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "Aarav_2008");
            String query = "select name from seedtype";
            statement = connection.prepareStatement(query);
            set = statement.executeQuery();

            while (set.next()) {
                options.add(set.getString("name"));
            }

            statement.close();
            set.close();

            // Return the List
            return options;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            if (set != null) {
                try {
                    set.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    return null;
                }

            }
        }
    }

    /**
     *Reads the information entered in the New Entry page when Enter is pressed
     */
    public void readEntry(ActionEvent event){
        String seedNameAdd = seedEntry_type_comboBox.getValue();
        int seedID = 0;

        //Finds the seedID number from the seed name
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "Aarav_2008");
            Statement statement = connection.createStatement();
            String query = new String("SELECT seed_id FROM seedtype WHERE name = " + "'" + seedNameAdd +"'");
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                seedID = resultSet.getInt("seed_id");
            }
        } catch (Exception e){
            e.printStackTrace();
        }

        int newQty = Integer.parseInt(seedEntry_quantity_textField.getText());
        String addMethod = seedEntry_methodObtained_comboBox.getValue();
        //String addMethod = "Harvested";
        String strExpDate = (seedEntry_year_textfield.getText() + "-" + seedEntry_month_textfield.getText() + "-" + seedEntry_day_textField.getText());
        java.sql.Date sqlExpDate = java.sql.Date.valueOf(strExpDate);

        SeedEntry newEntry = new SeedEntry(seedID, newQty, addMethod, sqlExpDate);
        addEntryToDatabase(newEntry);
    }

    /**
     *  Takes a seed entry and sends the information to the seedentry database
     */
    public void addEntryToDatabase (SeedEntry s){
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "Aarav_2008");
            Statement statement = connection.createStatement();
            String query = new String("INSERT INTO `test`.`seedentry` (`user_id`,`entry_date`, "
                    + "`seed_id`,`quantity_in_grams`,`method_obtained`,`expiry_date`,`status`)" +
                    "VALUES (" + s.get_user_id() + "," + "DATE '"+ s.get_entry_date() + "'" + ","+ s.get_seed_id() + "," +
                    s.get_quantity() + "," + "\"" + s.get_method_obtained() + "\"" + ","  + "DATE '"+ s.get_expiry_date() +
                    "'" + "," + "\"" + s.get_status() + "\");");
            statement.executeUpdate(query);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        sidebar_logout_btn.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                Driver.shiftScene1(event, "login.fxml","Hello", null);
            }
        });
    }

    public void setUserInformation(String username) {
        sidebar_loggedInAs.setText("Logged In");
        sidebar_preferredAlias.setText(username);
    }

}


