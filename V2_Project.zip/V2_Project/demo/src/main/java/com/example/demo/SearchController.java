package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SearchController {
    @FXML
    private Label welcomeText;
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Label sidebar_loggedInAs;

    @FXML
    private Label sidebar_preferredAlias;

    @FXML
    private Label dashboard_preferredAlias;

    @FXML
    private RadioButton search_category_radioButton, search_plantingTime_radioButton, search_expiryDate_radioButton;

    @FXML
    private TextField search_searchBar_textfield;

    @FXML
    private TableView search_resultsTable;

    //SIDE NAVIGATION BAR /////////////////////////////////////////////////////////////////////////////
    public void goToDashboard(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToSeedEntry(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("seedEntry.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToSearch(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("search.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToPlantingSchedule(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("plantingSchedule.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToUserSettings(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("userSettings.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToReports(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("reports.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void logoutButton(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("login.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    //SIDE NAVIGATION BAR /////////////////////////////////////////////////////////////////////////////

    public void setUserInformation(String username) {
        sidebar_loggedInAs.setText("Logged In As");
        sidebar_preferredAlias.setText(username);
        dashboard_preferredAlias.setText(username);
    }

    public void selectCategory(ActionEvent event){
        search_expiryDate_radioButton.setSelected(false);
        search_plantingTime_radioButton.setSelected(false);
    }

    public void selectExpiry(ActionEvent event){
        search_category_radioButton.setSelected(false);
        search_plantingTime_radioButton.setSelected(false);
    }

    public void selectPlanting(ActionEvent event){
        search_category_radioButton.setSelected(false);
        search_expiryDate_radioButton.setSelected(false);
    }

    public void searchItems(ActionEvent event){
        String searchVal = search_searchBar_textfield.getText();

        if(search_category_radioButton.isSelected()){
            searchCategory(searchVal);
        } else if(search_expiryDate_radioButton.isSelected()){
            searchExpiryDate(searchVal);
        } else if(search_plantingTime_radioButton.isSelected()){
            searchPlantingTime(searchVal);
        }
    }

    public void searchCategory(String searchString){
        ObservableList categoryResults = FXCollections.observableArrayList();
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "aarav_2008");
            Statement statement = connection.createStatement();
            String query = new String("SELECT entry_id, seedtype.name, entry_date, seedentry.seed_id, quantity_in_grams, method_obtained, expiry_date, seedentry.status, seedtype.category \n" +
                    "FROM seedentry,seedtype \n" +
                    "WHERE seedtype.category \n" +
                    "LIKE '%" + searchString + "%' AND seedentry.seed_id = seedtype.seed_id;");
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                ObservableList entries = FXCollections.observableArrayList();
                for (int i = 1; i < resultSet.getMetaData().getColumnCount(); i++){
                    entries.add(resultSet.getString(i));
                }
                categoryResults.add(entries);
            }
            search_resultsTable.setItems(categoryResults);

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void searchPlantingTime(String searchString){
        ObservableList categoryResults = FXCollections.observableArrayList();
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "aarav_2008");
            Statement statement = connection.createStatement();
            String query = new String("SELECT entry_id, seedtype.name, entry_date, seedentry.seed_id, quantity_in_grams, method_obtained, expiry_date, seedentry.status, seedtype.category \n" +
                    "FROM seedentry,seedtype \n" +
                    "WHERE seedtype.planting_time \n" +
                    "LIKE '%" + searchString + "%' AND seedentry.seed_id = seedtype.seed_id;");
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                ObservableList entries = FXCollections.observableArrayList();
                for (int i = 1; i < resultSet.getMetaData().getColumnCount(); i++){
                    entries.add(resultSet.getString(i));
                }
                categoryResults.add(entries);
            }
            search_resultsTable.setItems(categoryResults);

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void searchExpiryDate(String searchString){
        ObservableList categoryResults = FXCollections.observableArrayList();
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "aarav_2008");
            Statement statement = connection.createStatement();
            String query = new String("SELECT entry_id, seedtype.name, entry_date, seedentry.seed_id, quantity_in_grams, method_obtained, expiry_date, seedentry.status, seedtype.category \n" +
                    "FROM seedentry,seedtype \n" +
                    "WHERE seedentry.expiry_date \n" +
                    "LIKE '%" + searchString + "%' AND seedentry.seed_id = seedtype.seed_id;");
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                ObservableList entries = FXCollections.observableArrayList();
                for (int i = 1; i < resultSet.getMetaData().getColumnCount(); i++){
                    entries.add(resultSet.getString(i));
                }
                categoryResults.add(entries);
            }
            search_resultsTable.setItems(categoryResults);

        } catch (Exception e){
            e.printStackTrace();
        }
    }

}