package com.example.demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class SeedEntry {
    private int entry_id;
    private int user_id;
    private int seed_id;
    private Date entry_date;
    private Date expiry_date;
    private int quantity_in_grams;
    private String method_obtained;
    private String status;

    public SeedEntry (){
    }

    public SeedEntry(int seed_id, int quantity_in_grams, String method_obtained,
                     Date expiry_date) {
        this.entry_id = entry_id;
        this.user_id = 001;
        this.seed_id = seed_id;
        java.util.Date date = new java.util.Date();
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());
        this.entry_date = sqlDate;
        this.quantity_in_grams = quantity_in_grams;
        this.method_obtained = method_obtained;
        this.expiry_date = expiry_date;
        this.status = "Ready";
    }

    public int get_entry_id(){
        return entry_id;
    }
    public int get_user_id(){
        return user_id;
    }
    public int get_seed_id(){
        return seed_id;
    }
    public Date get_entry_date(){
        return entry_date;
    }
    public int get_quantity(){
        return quantity_in_grams;
    }
    public String get_method_obtained(){
        return method_obtained;
    }
    public Date get_expiry_date(){
        return expiry_date;
    }
    public String get_status(){
        return status;
    }
    public void set_status(String newStatus){
        this.status = newStatus;
    }

}
