package com.example.demo;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Report{
    public SimpleIntegerProperty report_id = new SimpleIntegerProperty();
    public SimpleIntegerProperty user_id = new SimpleIntegerProperty();
    public SimpleIntegerProperty report_type = new SimpleIntegerProperty();
    public  SimpleStringProperty report_date = new SimpleStringProperty();

    public Report(int report_id, int user_id, int report_type, String report_date) {

    }

    public int getReportID() {
        return this.report_id.get();
    }
    public void setReportID(int report_id) {
        this.report_id.set(report_id);
    }

    public int getUserID() {
        return this.user_id.get();
    }
    public void setUserID(int user_id) {
        this.user_id.set(user_id);
    }
    public int getReportType() {
        return this.report_type.get();
    }
    public void setReportType(int report_type) {
        this.report_type.set(report_type);
    }
    public String getReportDate() {
        return report_date.get();
    }
    public void setReportDate(String report_date) {
        this.report_date.set(report_date);
    }

}