package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class ReportsController implements Initializable {

    @FXML
    private Label welcomeText;
    @FXML
    private Stage stage;
    @FXML
    private Scene scene;
    @FXML
    private Parent root;
    @FXML
    private Label sidebar_loggedInAs;
    @FXML
    private Label sidebar_preferredAlias;
    @FXML
    private Label dashboard_preferredAlias;
    @FXML
    private TableView<Report> reports_reports_table;
    @FXML
    private TableColumn<Report, Integer> report_id;
    @FXML
    private TableColumn<Report, Integer> user_id;
    @FXML
    private TableColumn<Report, Integer> report_type;
    @FXML
    private TableColumn<Report, String> report_date;
    /**
     * Initializes the controller class.
     */
    private ObservableList<Report> data;
    Connection connection;
    PreparedStatement statement;
    ResultSet set = null;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        data = FXCollections.observableArrayList();
        report_id = new TableColumn<Report, Integer>("report_id");
        report_id.setCellValueFactory(new PropertyValueFactory<Report, Integer>("report_id"));

        user_id = new TableColumn<Report, Integer>("user_id");
        user_id.setCellValueFactory(new PropertyValueFactory<Report, Integer>("user_id"));

        report_type = new TableColumn<Report, Integer>("report_type");
        report_type.setCellValueFactory(new PropertyValueFactory<Report, Integer>("report_type"));

        report_date = new TableColumn<Report, String>("report_date");
        report_date.setCellValueFactory(new PropertyValueFactory<Report, String>("report_date"));

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "100272227");
            String query = "select * from report";
            statement = connection.prepareStatement(query);
            set = statement.executeQuery();



            while (set.next()) {
                data.add(new Report(
                        set.getInt("report_id"),
                        set.getInt("user_id"),
                        set.getInt("report_type"),
                        set.getString("report_date")
                ));
            }
            reports_reports_table.getItems().setAll(data);

        }catch (Exception e){
            e.printStackTrace();;
            System.out.println("error");
        }

    }

    @FXML
    private void handleAddButton(ActionEvent event) throws IOException{
    }


    //SIDE NAVIGATION BAR /////////////////////////////////////////////////////////////////////////////
    public void goToDashboard(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToSeedEntry(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("seedEntry.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToSearch(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("search.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToPlantingSchedule(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("plantingSchedule.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToUserSettings(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("userSettings.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToReports(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("reports.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void logoutButton(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("login.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    //SIDE NAVIGATION BAR /////////////////////////////////////////////////////////////////////////////




    public void setUserInformation(String username) {
        sidebar_loggedInAs.setText("Logged In As");
        sidebar_preferredAlias.setText(username);
        dashboard_preferredAlias.setText(username);
    }


}